let cars = ["toyota","mazda","vivo"];
let mycar = cars[0]
 console.log(mycar);